# finstagram-template
Instructions to run:
```
pip install -r requirements
python app.py
```
